import java.util.*;
public class Main{
    public static String lr(String s, int d) {
        String result = s.substring(d) + s.substring(0, d);
        return result;
    }
    public static String rr(String s, int d) {
        int n = s.length();
        d = d % n;
        String result = lr(s, n - d);
        return result;
    }
    public static void main(String[] args){
        Scanner ps = new Scanner(System.in);
        String s = ps.next();
        int d = ps.nextInt();
        char ch = '"';
        System.out.println("Left Rotation:"+ch+ lr(s, d)+ch);
        System.out.println("Right Rotation:"+ch+rr(s, d)+ch);
    }
}
